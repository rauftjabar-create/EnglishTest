# Design brief — Grammar Quiz

## Direction
**Study-lab editorial**: a calm, high-contrast learning workspace with a warm paper background, ink-dark typography, and a vivid coral accent for active learning moments.

## Design movement
Editorial education meets a focused dashboard: generous margins, strong typographic hierarchy, crisp cards, and a small amount of playful geometry.

## Core principles
- Make the next action obvious: one question, four generous answer buttons, one clear continuation.
- Keep cognitive load low with visible progress, topic labels, and concise feedback.
- Use color as feedback, never as decoration alone: coral for action, green for correct, amber/red for learning moments.
- Keep the product English-first while showing Kurdish explanations only when a choice is wrong.

## Color philosophy
Warm ivory canvas (#f7f4ee), ink navy (#17222d), slate text (#61707d), coral accent (#ef6b5b), mint success (#2f9b78), and soft amber for learning feedback.

## Layout paradigm
A responsive two-column learning workspace on desktop: the question card dominates, while a compact progress rail gives context. On mobile, the rail becomes a compact top summary and answer buttons remain thumb-friendly.

## Signature elements
- Coral “Q” mark as the project icon and header wordmark.
- A small eyebrow label for the current topic.
- Chunky progress bar with a moving coral fill.
- Answer buttons with letter badges and restrained hover lift.
- Feedback panel that visually separates English correction from Kurdish explanation.

## Interaction philosophy
Instant answer state, no typing, no ambiguous controls. After choosing, the selected answer locks, feedback appears, and the learner advances with one deliberate button.

## Animation
Short ease-out transitions for answer selection, progress changes, and completion reveal. Respect reduced-motion preferences.

## Typography system
Use system UI for speed and readability, with a serif display fallback for the large quiz title. Body copy is compact and highly legible; labels use uppercase tracking sparingly.

## Brand essence and voice
Encouraging, direct, and focused. The quiz should feel like a friendly coach, not an exam proctor.

## Wordmark / logo
“Grammar Quiz” paired with a coral square Q glyph; the glyph uses negative space to suggest a speech bubble and a question mark.

## Signature brand color
Coral #ef6b5b.
